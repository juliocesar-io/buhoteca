﻿'
' Creado por SharpDevelop.
' Usuario: sala4
' Fecha: 20/10/2014
' Hora: 06:48 p.m.
' 
' Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
'
Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Sub Button1Click(sender As Object, e As EventArgs)
		If open.ShowDialog=dialogresult.OK Then 
			tb1.text=open.FileName
		End If
		
	End Sub
	
	Sub Button2Click(sender As Object, e As EventArgs)
		If save.ShowDialog=dialogresult.OK Then 
			tb2.text=save.FileName
		End If
	End Sub
	
	Sub Button3Click(sender As Object, e As EventArgs)
		Dim bin As cbinario
		bin=New cbinario
		bin.setorigen(tb1.text)
		bin.setdestino(tb2.text)
		bin.copiar
		msgbox("archivo copiado")
	End Sub
	
	Sub Button4Click(sender As Object, e As EventArgs)
		Dim bin As cbinario
		bin=New cbinario
		bin.setorigen(tb1.text)
		bin.setdestino(tb2.text)
		bin.setmascara(CByte(tb3.text))
		bin.encriptar
		msgbox("archivo encriptado")
	End Sub
End Class
