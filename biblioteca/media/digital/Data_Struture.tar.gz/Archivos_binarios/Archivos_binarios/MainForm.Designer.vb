﻿'
' Creado por SharpDevelop.
' Usuario: sala4
' Fecha: 20/10/2014
' Hora: 06:48 p.m.
' 
' Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
'
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.label1 = New System.Windows.Forms.Label
		Me.tb1 = New System.Windows.Forms.TextBox
		Me.button1 = New System.Windows.Forms.Button
		Me.tb2 = New System.Windows.Forms.TextBox
		Me.label2 = New System.Windows.Forms.Label
		Me.button2 = New System.Windows.Forms.Button
		Me.button3 = New System.Windows.Forms.Button
		Me.tb3 = New System.Windows.Forms.TextBox
		Me.label3 = New System.Windows.Forms.Label
		Me.button4 = New System.Windows.Forms.Button
		Me.save = New System.Windows.Forms.SaveFileDialog
		Me.open = New System.Windows.Forms.OpenFileDialog
		Me.SuspendLayout
		'
		'label1
		'
		Me.label1.Location = New System.Drawing.Point(21, 16)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(103, 16)
		Me.label1.TabIndex = 0
		Me.label1.Text = "ARCHIVO ORIGEN"
		'
		'tb1
		'
		Me.tb1.Location = New System.Drawing.Point(24, 38)
		Me.tb1.Name = "tb1"
		Me.tb1.Size = New System.Drawing.Size(100, 20)
		Me.tb1.TabIndex = 1
		'
		'button1
		'
		Me.button1.Location = New System.Drawing.Point(144, 35)
		Me.button1.Name = "button1"
		Me.button1.Size = New System.Drawing.Size(75, 23)
		Me.button1.TabIndex = 2
		Me.button1.Text = "ABRIR"
		Me.button1.UseVisualStyleBackColor = true
		AddHandler Me.button1.Click, AddressOf Me.Button1Click
		'
		'tb2
		'
		Me.tb2.Location = New System.Drawing.Point(262, 35)
		Me.tb2.Name = "tb2"
		Me.tb2.Size = New System.Drawing.Size(109, 20)
		Me.tb2.TabIndex = 3
		'
		'label2
		'
		Me.label2.Location = New System.Drawing.Point(262, 16)
		Me.label2.Name = "label2"
		Me.label2.Size = New System.Drawing.Size(109, 16)
		Me.label2.TabIndex = 4
		Me.label2.Text = "ARCHIVO DESTINO"
		'
		'button2
		'
		Me.button2.Location = New System.Drawing.Point(405, 35)
		Me.button2.Name = "button2"
		Me.button2.Size = New System.Drawing.Size(75, 23)
		Me.button2.TabIndex = 5
		Me.button2.Text = "GUARDAR"
		Me.button2.UseVisualStyleBackColor = true
		AddHandler Me.button2.Click, AddressOf Me.Button2Click
		'
		'button3
		'
		Me.button3.Location = New System.Drawing.Point(24, 114)
		Me.button3.Name = "button3"
		Me.button3.Size = New System.Drawing.Size(75, 23)
		Me.button3.TabIndex = 6
		Me.button3.Text = "COPIAR"
		Me.button3.UseVisualStyleBackColor = true
		AddHandler Me.button3.Click, AddressOf Me.Button3Click
		'
		'tb3
		'
		Me.tb3.Location = New System.Drawing.Point(144, 117)
		Me.tb3.Name = "tb3"
		Me.tb3.Size = New System.Drawing.Size(100, 20)
		Me.tb3.TabIndex = 7
		'
		'label3
		'
		Me.label3.Location = New System.Drawing.Point(165, 98)
		Me.label3.Name = "label3"
		Me.label3.Size = New System.Drawing.Size(63, 16)
		Me.label3.TabIndex = 8
		Me.label3.Text = "MASCARA"
		'
		'button4
		'
		Me.button4.Location = New System.Drawing.Point(279, 114)
		Me.button4.Name = "button4"
		Me.button4.Size = New System.Drawing.Size(92, 23)
		Me.button4.TabIndex = 9
		Me.button4.Text = "ENCRIPTAR"
		Me.button4.UseVisualStyleBackColor = true
		AddHandler Me.button4.Click, AddressOf Me.Button4Click
		'
		'save
		'
		Me.save.Title = "archivo destino"
		'
		'open
		'
		Me.open.FileName = "openFileDialog1"
		Me.open.Title = "abrir archivo origen"
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(554, 334)
		Me.Controls.Add(Me.button4)
		Me.Controls.Add(Me.label3)
		Me.Controls.Add(Me.tb3)
		Me.Controls.Add(Me.button3)
		Me.Controls.Add(Me.button2)
		Me.Controls.Add(Me.label2)
		Me.Controls.Add(Me.tb2)
		Me.Controls.Add(Me.button1)
		Me.Controls.Add(Me.tb1)
		Me.Controls.Add(Me.label1)
		Me.Name = "MainForm"
		Me.Text = "Archivos_Binarios"
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private tb1 As System.Windows.Forms.TextBox
	Private tb2 As System.Windows.Forms.TextBox
	Private tb3 As System.Windows.Forms.TextBox
	Private open As System.Windows.Forms.OpenFileDialog
	Private save As System.Windows.Forms.SaveFileDialog
	Private button4 As System.Windows.Forms.Button
	Private label3 As System.Windows.Forms.Label
	Private button3 As System.Windows.Forms.Button
	Private button2 As System.Windows.Forms.Button
	Private label2 As System.Windows.Forms.Label
	Private button1 As System.Windows.Forms.Button
	Private label1 As System.Windows.Forms.Label
End Class
