﻿'
' Creado por SharpDevelop.
' Usuario: sala4
' Fecha: 20/10/2014
' Hora: 07:06 p.m.
'
' Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
imports System.IO
Public Class cbinario
Private mascara As Byte
	Private origen As String
	Private destino As String
	Public Sub New()
		mascara=0
		origen=""
		destino=""
	End Sub
	Public Sub setmascara(mas As Byte)
		mascara=mas
	End Sub
	Public Sub setorigen (ori As String)
		origen=ori
	End Sub
	Public Sub setdestino(des As String)
		destino=des
	End Sub
	Public Function getmascara() As Byte
		return mascara
	End Function
	Public Function getorigen()As String
		return origen
	End Function
	Public Function getdestino() As String
		return destino
	End Function
	
	
	Public Sub copiar()
		Dim leidos As Integer
		Dim buffer(1024) As Byte '1kb
		Dim bw As BinaryWriter
		Dim br As BinaryReader
		
		br=New BinaryReader(file.Open(origen,filemode.Open))
		bw=New BinaryWriter(file.Open(destino,filemode.Create))
		While br.BaseStream.Position<br.BaseStream.Length
			leidos=br.Read(buffer,0,1024)
			If leidos>0 Then
				bw.Write(buffer,0,leidos)
			Else
				Exit While 
				end if
		End While
		br.close
		bw.Flush
		bw.Close
	End Sub
	
	
	Public Sub encriptar()
		Dim datos As Byte
		Dim bw As BinaryWriter
		Dim br As BinaryReader
		br=New BinaryReader(file.Open(origen,filemode.Open))
		bw=New BinaryWriter(file.Open(destino,filemode.Create))
		While br.BaseStream.Position<br.BaseStream.Length
			datos=br.ReadByte
			datos=datos Xor mascara
			bw.Write(datos)
		End While
		br.Close
		bw.Flush
		bw.Close
	End Sub
	
	
	
End Class
