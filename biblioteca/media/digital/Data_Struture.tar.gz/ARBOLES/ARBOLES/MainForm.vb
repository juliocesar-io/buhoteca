﻿'
' Creado por SharpDevelop.
' Usuario: Usuario
' Fecha: 07/10/2014
' Hora: 06:58 p. m.
'
' Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
'
Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Private Sub preorden (nodo As TreeNode)
		tbr.Text=tbr.Text & nodo.Text
		If nodo.Nodes.Count>0 Then
			preorden(nodo.Nodes(0) )
			If nodo.Nodes.Count=2 Then
				preorden(nodo.Nodes(1) )
			End If
		End If
	End Sub
	
	Private Sub inorden(nodo As TreeNode)
		If nodo.Nodes.Count>0 Then
			inorden(nodo.Nodes(0) )
		End If
		tbr.Text=tbr.Text & nodo.Text
		If nodo.Nodes.Count=2 Then
			inorden(nodo.Nodes(1) )
		End If
	End Sub
	
	Private Sub postorden(nodo As TreeNode)
		If nodo.Nodes.Count>0  Then
			postorden(nodo.Nodes(0) )
			If nodo.Nodes.Count=2 Then
				postorden(nodo.Nodes(1) )
			End If
		End If
		tbr.Text=tbr.text & nodo.Text
	End Sub
	
	
	
	
	Sub Button1Click(sender As Object, e As EventArgs)
		Dim padre As TreeNode
		If trv.Nodes.Count=0 Then
			trv.Nodes.Add(tb1.Text)
		Else
			padre=trv.SelectedNode
			If padre Is Nothing Then
				msgBox("seleccione padre")
				trv.Focus
		   Else
				If padre.Nodes.count<2 Then
					padre.Nodes.Add(tb1.Text)
					tb1.Text=""
					tb1.Focus
		      Else
					msgBox("el padre ya tiene dos hijos")
					trv.Focus
					
				End If
			End If
		End If
	End Sub
	
	Sub Button2Click(sender As Object, e As EventArgs)
		Dim nodo As TreeNode
		nodo=trv.SelectedNode
		If nodo Is Nothing Then
			msgBox("seleccione nodo")
			trv.Focus
		Else
			trv.Nodes.Remove(nodo)
		End If
	End Sub
	
	
	Sub Button3Click(sender As Object, e As EventArgs)
		trv.Nodes.clear
	End Sub
	
	
	
	Sub Button4Click(sender As Object, e As EventArgs)
		Dim raiz As TreeNode
		If trv.Nodes.Count>0 Then
			raiz=trv.Nodes(0)
			trv.text=""
		
		Select Case cb1.SelectedIndex
			Case 0
				preorden(raiz)
			Case 1
				inorden(raiz)
			Case 2
				postorden(raiz)
		End Select
		
		Else
			msgBox("arbol vacio") 
		End If
	End Sub
	
	
End Class
