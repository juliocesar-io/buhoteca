﻿'
' Creado por SharpDevelop.
' Usuario: Usuario
' Fecha: 07/10/2014
' Hora: 06:58 p. m.
' 
' Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
'
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.label1 = New System.Windows.Forms.Label
		Me.tb1 = New System.Windows.Forms.TextBox
		Me.button1 = New System.Windows.Forms.Button
		Me.button2 = New System.Windows.Forms.Button
		Me.button3 = New System.Windows.Forms.Button
		Me.trv = New System.Windows.Forms.TreeView
		Me.cb1 = New System.Windows.Forms.ComboBox
		Me.button4 = New System.Windows.Forms.Button
		Me.tbr = New System.Windows.Forms.TextBox
		Me.label2 = New System.Windows.Forms.Label
		Me.SuspendLayout
		'
		'label1
		'
		Me.label1.Location = New System.Drawing.Point(16, 9)
		Me.label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(133, 32)
		Me.label1.TabIndex = 0
		Me.label1.Text = "NODO"
		'
		'tb1
		'
		Me.tb1.Location = New System.Drawing.Point(17, 42)
		Me.tb1.Margin = New System.Windows.Forms.Padding(4)
		Me.tb1.Name = "tb1"
		Me.tb1.Size = New System.Drawing.Size(132, 25)
		Me.tb1.TabIndex = 1
		'
		'button1
		'
		Me.button1.Location = New System.Drawing.Point(187, 33)
		Me.button1.Name = "button1"
		Me.button1.Size = New System.Drawing.Size(128, 34)
		Me.button1.TabIndex = 2
		Me.button1.Text = "AGREGAR"
		Me.button1.UseVisualStyleBackColor = true
		AddHandler Me.button1.Click, AddressOf Me.Button1Click
		'
		'button2
		'
		Me.button2.Location = New System.Drawing.Point(346, 33)
		Me.button2.Name = "button2"
		Me.button2.Size = New System.Drawing.Size(128, 34)
		Me.button2.TabIndex = 3
		Me.button2.Text = "ELIMINAR"
		Me.button2.UseVisualStyleBackColor = true
		AddHandler Me.button2.Click, AddressOf Me.Button2Click
		'
		'button3
		'
		Me.button3.Location = New System.Drawing.Point(509, 33)
		Me.button3.Name = "button3"
		Me.button3.Size = New System.Drawing.Size(128, 34)
		Me.button3.TabIndex = 4
		Me.button3.Text = "LIMPIAR"
		Me.button3.UseVisualStyleBackColor = true
		AddHandler Me.button3.Click, AddressOf Me.Button3Click
		'
		'trv
		'
		Me.trv.Location = New System.Drawing.Point(17, 96)
		Me.trv.Name = "trv"
		Me.trv.Size = New System.Drawing.Size(620, 199)
		Me.trv.TabIndex = 5
		'
		'cb1
		'
		Me.cb1.FormattingEnabled = true
		Me.cb1.Items.AddRange(New Object() {"PRE-ORDEN", "IN-ORDEN", "POST-ORDEN"})
		Me.cb1.Location = New System.Drawing.Point(99, 335)
		Me.cb1.Name = "cb1"
		Me.cb1.Size = New System.Drawing.Size(121, 26)
		Me.cb1.TabIndex = 6
		'
		'button4
		'
		Me.button4.Location = New System.Drawing.Point(270, 330)
		Me.button4.Name = "button4"
		Me.button4.Size = New System.Drawing.Size(128, 34)
		Me.button4.TabIndex = 7
		Me.button4.Text = "ACEPTAR"
		Me.button4.UseVisualStyleBackColor = true
		AddHandler Me.button4.Click, AddressOf Me.Button4Click
		'
		'tbr
		'
		Me.tbr.Location = New System.Drawing.Point(468, 335)
		Me.tbr.Name = "tbr"
		Me.tbr.ReadOnly = true
		Me.tbr.Size = New System.Drawing.Size(121, 25)
		Me.tbr.TabIndex = 8
		'
		'label2
		'
		Me.label2.Location = New System.Drawing.Point(468, 309)
		Me.label2.Name = "label2"
		Me.label2.Size = New System.Drawing.Size(100, 23)
		Me.label2.TabIndex = 9
		Me.label2.Text = "RESULTADO"
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8!, 18!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(692, 387)
		Me.Controls.Add(Me.label2)
		Me.Controls.Add(Me.tbr)
		Me.Controls.Add(Me.button4)
		Me.Controls.Add(Me.cb1)
		Me.Controls.Add(Me.trv)
		Me.Controls.Add(Me.button3)
		Me.Controls.Add(Me.button2)
		Me.Controls.Add(Me.button1)
		Me.Controls.Add(Me.tb1)
		Me.Controls.Add(Me.label1)
		Me.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "MainForm"
		Me.Text = "ARBOLES"
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private trv As System.Windows.Forms.TreeView
	Private label2 As System.Windows.Forms.Label
	Private tbr As System.Windows.Forms.TextBox
	Private button4 As System.Windows.Forms.Button
	Private cb1 As System.Windows.Forms.ComboBox
	Private button3 As System.Windows.Forms.Button
	Private button2 As System.Windows.Forms.Button
	Private button1 As System.Windows.Forms.Button
	Private tb1 As System.Windows.Forms.TextBox
	Private label1 As System.Windows.Forms.Label
End Class
