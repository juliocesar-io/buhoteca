﻿Imports FirebirdSql.Data.FirebirdClient

Public Partial Class MainForm
	
 Private Con As FbConnection	
	
 Public Sub New()
  Me.InitializeComponent()
  Con=Nothing	
 End Sub
 
 Private Sub Conectar()
  Dim StrCon As FbConnectionStringBuilder
  Con=New FbConnection()
  StrCon=New FbConnectionStringBuilder()
  StrCon.UserID="sysdba"
  StrCon.Password="masterkey"
  StrCon.Database="c:\basedatos\ejemplo.fdb"
  Con.ConnectionString=StrCon.ToString()
  Con.Open()
 End Sub
 
 Private Sub Desconectar()
  If Not (Con Is Nothing) Then
  	If Con.State=1 Then
  	 Con.Close()
  	 Con.Dispose()
  	 Con=Nothing
   End If
  End If
 End Sub
	
	
 Sub MainFormLoad(sender As Object, e As EventArgs)
  Conectar()		
 End Sub
 
	
 Sub MainFormFormClosed(sender As Object, e As FormClosedEventArgs)
  Desconectar()		
 End Sub
 
 
 Private Function Ejecutar(Sql As String) As Integer
  Dim Res As Integer	
  Dim Cmd As FbCommand
  Cmd=Con.CreateCommand
  Cmd.CommandText=Sql
  Res=Cmd.ExecuteNonQuery()
  Cmd.Dispose()
  Return Res
 End Function
 
 Private Function Seleccionar(Sql As String) As FbDataReader
  Dim Cmd As FbCommand
  Dim Res As FbDataReader
  Cmd=Con.CreateCommand
  Cmd.CommandText=Sql
  Res=Cmd.ExecuteReader
  Return Res	
 End Function
 
 Private Sub Mostrar(Res As FbDataReader)
  Dim Fila As ListViewItem
  Lv.Items.Clear
  While Res.Read 
  	Fila=Lv.Items.Add(Res.GetInt32(0))
  	Fila.SubItems.Add(Res.GetString(1))
  	Fila.SubItems.Add(Res.GetString(2))
  	Fila.SubItems.Add(Res.GetInt16(3))
  End While
 End Sub

	
 Sub B1Click(sender As Object, e As EventArgs)
  Dim Sql As String 
  Sql="Insert Into TPersonas Values({0},'{1}','{2}',{3})"	
  Sql=Sql.Format(Sql,tb1.Text,tb2.Text,tb3.Text,tb4.Text)
  If Ejecutar(Sql)=1 Then
   MsgBox("Persona guardada")	
  Else
    MsgBox("Error guardando persona")	 
  End If
 End Sub
 
	
 Sub Button1Click(sender As Object, e As EventArgs)
  Dim Sql As String 
  Sql="Update TPersonas Set Apellidos='{1}',Nombres='{2}',Edad={3}"	
  Sql=Sql & " Where Cedula={0}" 
  Sql=Sql.Format(Sql,tb1.Text,tb2.Text,tb3.Text,tb4.Text)
  If Ejecutar(Sql)=1 Then
   MsgBox("Persona modificada")	
  Else
    MsgBox("Error modificando persona")	 
  End If		
 End Sub
 
	
 Sub Button2Click(sender As Object, e As EventArgs)
  Dim Sql As String 
  Sql="Delete From TPersonas Where Cedula=" & tb1.Text  
  If Ejecutar(Sql)=1 Then
   MsgBox("Persona eliminada")	
  Else
    MsgBox("Error eliminando persona")	 
  End If			
 End Sub
 
	
 sub Button3Click(sender As Object, e As EventArgs)
  Dim Sql As String 
  Sql="Select * From TPersonas"
  If tb1.Text<>"" Then
   Sql=Sql & " Where Cedula=" & tb1.Text	
  End If
  Mostrar(Seleccionar(Sql))
 End Sub
 
End Class
