﻿'
' Creado por SharpDevelop.
' Usuario: Usuario
' Fecha: 27/10/2014
' Hora: 06:30 p. m.
' 
' Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar

Imports system.IO

Public Class CBinario
Private archivo As String 
Private cedula As Integer
Private apellidos As String
Private nombres As String 
private edad as Byte 

Public Sub New () 
	archivo="" 
	cedula=0
	nombres=""
	apellidos=""
	edad=0 
End Sub

Public sub setArchivo(arch As String) 
archivo=arch
End Sub 

Public Sub setcedula(ced As String) 
	cedula=ced
End Sub

Public Sub setNombres(nom As String)
	nombres=nom 
End Sub

Public Sub setEdad(eda As Byte) 
	edad=eda
End Sub

Public Function getCedula() As Integer
	return cedula 
End Function

Public Function getApellidos() As String 
	return apellidos
End Function

Public Function getNombres () As String 
	return nombres 
End Function

Public Function getEdad() As Byte
	return edad 
End Function

Public Function abrirEscritura() As BinaryWriter 
	Dim BW As BinaryWriter
	BW= New BinaryWriter(file.Open(archivo,FileMode.create)) 
	return BW 
End Function

Public Function abrirLectura() As BinaryReader
	Dim BR As BinaryReader
	BR=new BinaryReader(file.Open(archivo,fileMode.open)) 
End Function

Public Sub guardar (BW As BinaryWriter) 
	BW.Write (cedula) 
	BW.Write (apellidos) 
	BW.Write (nombres) 
	BW.Write (edad) 
	BW.Flush
End Sub

Public Sub leer(BR As BinaryReader) 
	cedula=BR.ReadInt32
	apellidos=BR.ReadString
	nombres=BR.ReadString
	edad=BR.ReadByte
End Sub


End Class
