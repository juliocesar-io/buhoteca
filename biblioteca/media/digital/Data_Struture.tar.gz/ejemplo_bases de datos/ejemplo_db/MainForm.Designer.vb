﻿'
' Created by SharpDevelop.
' User: Usuario
' Date: 21/10/2014
' Time: 6:39 p. m.
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class MainForm
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.label1 = New System.Windows.Forms.Label()
		Me.label2 = New System.Windows.Forms.Label()
		Me.label3 = New System.Windows.Forms.Label()
		Me.label4 = New System.Windows.Forms.Label()
		Me.tb1 = New System.Windows.Forms.TextBox()
		Me.tb2 = New System.Windows.Forms.TextBox()
		Me.tb3 = New System.Windows.Forms.TextBox()
		Me.tb4 = New System.Windows.Forms.TextBox()
		Me.B1 = New System.Windows.Forms.Button()
		Me.button1 = New System.Windows.Forms.Button()
		Me.button2 = New System.Windows.Forms.Button()
		Me.button3 = New System.Windows.Forms.Button()
		Me.Lv = New System.Windows.Forms.ListView()
		Me.columnHeader1 = New System.Windows.Forms.ColumnHeader()
		Me.columnHeader2 = New System.Windows.Forms.ColumnHeader()
		Me.columnHeader3 = New System.Windows.Forms.ColumnHeader()
		Me.columnHeader4 = New System.Windows.Forms.ColumnHeader()
		Me.SuspendLayout
		'
		'label1
		'
		Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.label1.Location = New System.Drawing.Point(15, 27)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(71, 20)
		Me.label1.TabIndex = 0
		Me.label1.Text = "Cedula"
		'
		'label2
		'
		Me.label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.label2.Location = New System.Drawing.Point(93, 24)
		Me.label2.Name = "label2"
		Me.label2.Size = New System.Drawing.Size(71, 20)
		Me.label2.TabIndex = 1
		Me.label2.Text = "Apellidos"
		'
		'label3
		'
		Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.label3.Location = New System.Drawing.Point(287, 24)
		Me.label3.Name = "label3"
		Me.label3.Size = New System.Drawing.Size(71, 20)
		Me.label3.TabIndex = 2
		Me.label3.Text = "Nombres"
		'
		'label4
		'
		Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.label4.Location = New System.Drawing.Point(486, 24)
		Me.label4.Name = "label4"
		Me.label4.Size = New System.Drawing.Size(57, 20)
		Me.label4.TabIndex = 3
		Me.label4.Text = "Edad"
		'
		'tb1
		'
		Me.tb1.Location = New System.Drawing.Point(16, 43)
		Me.tb1.Name = "tb1"
		Me.tb1.Size = New System.Drawing.Size(71, 20)
		Me.tb1.TabIndex = 4
		'
		'tb2
		'
		Me.tb2.Location = New System.Drawing.Point(93, 43)
		Me.tb2.Name = "tb2"
		Me.tb2.Size = New System.Drawing.Size(180, 20)
		Me.tb2.TabIndex = 5
		'
		'tb3
		'
		Me.tb3.Location = New System.Drawing.Point(287, 43)
		Me.tb3.Name = "tb3"
		Me.tb3.Size = New System.Drawing.Size(180, 20)
		Me.tb3.TabIndex = 6
		'
		'tb4
		'
		Me.tb4.Location = New System.Drawing.Point(486, 43)
		Me.tb4.Name = "tb4"
		Me.tb4.Size = New System.Drawing.Size(71, 20)
		Me.tb4.TabIndex = 7
		'
		'B1
		'
		Me.B1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.B1.Location = New System.Drawing.Point(16, 89)
		Me.B1.Name = "B1"
		Me.B1.Size = New System.Drawing.Size(75, 23)
		Me.B1.TabIndex = 8
		Me.B1.Text = "Guardar"
		Me.B1.UseVisualStyleBackColor = true
		AddHandler Me.B1.Click, AddressOf Me.B1Click
		'
		'button1
		'
		Me.button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.button1.Location = New System.Drawing.Point(106, 89)
		Me.button1.Name = "button1"
		Me.button1.Size = New System.Drawing.Size(75, 23)
		Me.button1.TabIndex = 9
		Me.button1.Text = "Modificar"
		Me.button1.UseVisualStyleBackColor = true
		AddHandler Me.button1.Click, AddressOf Me.Button1Click
		'
		'button2
		'
		Me.button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.button2.Location = New System.Drawing.Point(198, 89)
		Me.button2.Name = "button2"
		Me.button2.Size = New System.Drawing.Size(75, 23)
		Me.button2.TabIndex = 10
		Me.button2.Text = "Eliminar"
		Me.button2.UseVisualStyleBackColor = true
		AddHandler Me.button2.Click, AddressOf Me.Button2Click
		'
		'button3
		'
		Me.button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
		Me.button3.Location = New System.Drawing.Point(297, 89)
		Me.button3.Name = "button3"
		Me.button3.Size = New System.Drawing.Size(75, 23)
		Me.button3.TabIndex = 11
		Me.button3.Text = "Consultar"
		Me.button3.UseVisualStyleBackColor = true
		AddHandler Me.button3.Click, AddressOf Me.Button3Click
		'
		'Lv
		'
		Me.Lv.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeader1, Me.columnHeader2, Me.columnHeader3, Me.columnHeader4})
		Me.Lv.FullRowSelect = true
		Me.Lv.GridLines = true
		Me.Lv.Location = New System.Drawing.Point(19, 125)
		Me.Lv.Name = "Lv"
		Me.Lv.Size = New System.Drawing.Size(537, 210)
		Me.Lv.TabIndex = 12
		Me.Lv.UseCompatibleStateImageBehavior = false
		Me.Lv.View = System.Windows.Forms.View.Details
		'
		'columnHeader1
		'
		Me.columnHeader1.Text = "Cedula"
		Me.columnHeader1.Width = 99
		'
		'columnHeader2
		'
		Me.columnHeader2.Text = "Apellidos"
		Me.columnHeader2.Width = 174
		'
		'columnHeader3
		'
		Me.columnHeader3.Text = "Nombres"
		Me.columnHeader3.Width = 173
		'
		'columnHeader4
		'
		Me.columnHeader4.Text = "Edad"
		Me.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
		'
		'MainForm
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(562, 347)
		Me.Controls.Add(Me.Lv)
		Me.Controls.Add(Me.button3)
		Me.Controls.Add(Me.button2)
		Me.Controls.Add(Me.button1)
		Me.Controls.Add(Me.B1)
		Me.Controls.Add(Me.tb4)
		Me.Controls.Add(Me.tb3)
		Me.Controls.Add(Me.tb2)
		Me.Controls.Add(Me.tb1)
		Me.Controls.Add(Me.label4)
		Me.Controls.Add(Me.label3)
		Me.Controls.Add(Me.label2)
		Me.Controls.Add(Me.label1)
		Me.Name = "MainForm"
		Me.Text = "Ejemplo base de datos"
		AddHandler FormClosed, AddressOf Me.MainFormFormClosed
		AddHandler Load, AddressOf Me.MainFormLoad
		Me.ResumeLayout(false)
		Me.PerformLayout
	End Sub
	Private columnHeader4 As System.Windows.Forms.ColumnHeader
	Private columnHeader3 As System.Windows.Forms.ColumnHeader
	Private columnHeader2 As System.Windows.Forms.ColumnHeader
	Private columnHeader1 As System.Windows.Forms.ColumnHeader
	Private Lv As System.Windows.Forms.ListView
	Private button3 As System.Windows.Forms.Button
	Private button2 As System.Windows.Forms.Button
	Private button1 As System.Windows.Forms.Button
	Private B1 As System.Windows.Forms.Button
	Private tb4 As System.Windows.Forms.TextBox
	Private tb3 As System.Windows.Forms.TextBox
	Private tb2 As System.Windows.Forms.TextBox
	Private tb1 As System.Windows.Forms.TextBox
	Private label4 As System.Windows.Forms.Label
	Private label3 As System.Windows.Forms.Label
	Private label2 As System.Windows.Forms.Label
	Private label1 As System.Windows.Forms.Label
End Class
