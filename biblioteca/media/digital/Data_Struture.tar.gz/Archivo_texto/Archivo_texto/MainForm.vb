﻿'
' Creado por SharpDevelop.
' Usuario: Usuario
' Fecha: 14/10/2014
' Hora: 06:34 p. m.
' 
' Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
'
imports System.IO 
Public Partial Class MainForm
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Private Sub agregarFila()
		Dim fila As ListViewItem 
		fila=LV.Items.Add(tb1.text) 
		fila.SubItems.Add(tb2.text) 
		fila.SubItems.Add(tb3.text) 
		fila.SubItems.Add(tb4.text) 
	End Sub
	
	Private Sub limpiar() 
		tb1.text=""
		tb2.text=""
		tb3.text=""
		tb4.text=""
		tb1.focus 
	End Sub
	
	Private Sub guardarPer(fila As ListViewItem, AT As StreamWriter) 
		AT.WriteLine(fila.SubItems(0).Text) 
		AT.WriteLine(fila.SubItems(1).Text) 
		AT.WriteLine(fila.SubItems(2).Text) 
		AT.WriteLine(fila.SubItems(3).Text) 
	End Sub
	
	Private Sub guardarArch(nom As String) 
		Dim i As Integer
		Dim AT As StreamWriter
		AT= file.CreateText(nom) 
		For i=0 To LV.Items.Count-1 
			guardarPer(LV.Items(i), AT) 
		Next i 
		AT.Flush 
		AT.Close
		MsgBox("archivo guardado") 
	End Sub
	
	Private Sub leerArch( nom As String) 
		Dim fila As ListViewItem 
		Dim AT As StreamReader
		LV.Items.Clear
		AT=file.OpenText(nom) 
		While Not AT.EndOfStream
			fila=LV.Items.Add(AT.readline) 
			fila.SubItems.Add(AT.readline)
			fila.SubItems.Add(AT.readline)
			fila.SubItems.Add(AT.readline)
		End While
		AT.Close
	End Sub
	
	


	
	
	Sub TextBox3TextChanged(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub TextBox2TextChanged(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub Label3Click(sender As Object, e As EventArgs)
		
	End Sub
	
	Sub Button1Click(sender As Object, e As EventArgs)
		agregarFila 
		limpiar 
	End Sub
	
	
	
	Sub Button2Click(sender As Object, e As EventArgs)
		If LV.SelectedIndices.Count>0 then 
		LV.Items.RemoveAT(LV.SelectedIndices(0)) 
	    End If
	End Sub
	
	
	
	
	Sub Button4Click(sender As Object, e As EventArgs)
		guardarArch("Personas.text") 
	End Sub
	
	
	
	Sub Button3Click(sender As Object, e As EventArgs)
		LV.Items.Clear
	End Sub
	
	
	
	Sub Button5Click(sender As Object, e As EventArgs)
		leerArch("personas.text") 
	End Sub
End Class
